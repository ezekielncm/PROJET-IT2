<nav>
    <ul>
        <li><a href="/">Accueil</a></li>
        <li><a href="/propriete">Propriété</a></li>
        <li><a href="/client">Espace Client</a></li>
        <li><a href="/bailleur">Espace Bailleur</a></li>
        <li><a href="/manager">Espace Manager</a></li>
       <li><a href="/connexion-agent">Espace Agent</a></li>
        <!-- Ajoute d'autres liens si besoin -->
    </ul>
</nav>
