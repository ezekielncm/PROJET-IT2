    <footer>
        <p>&copy; UrbanHome - Tous droits réservés - 2025</p>
    </footer>
    </body>
</html>
